package pivotal;

import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.client.ClientCache;
import com.gemstone.gemfire.cache.client.ClientRegionShortcut;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Random;

/**
 * Created by pivotal on 9/22/15.
 */
@RestController
public class Client {

    @Autowired
//    @Qualifier("my-client-cache")
    ClientCache cache;
    Region myRegion;

    @RequestMapping("/dotest")
    public String doTest() {

       if(myRegion == null){
           myRegion = cache.createClientRegionFactory(ClientRegionShortcut.PROXY).create("test");
//         myRegion = cache.createClientRegionFactory(ClientRegionShortcut.CACHING_PROXY).create("test");
       }
//       String myKey = UUID.randomUUID().toString();
//     myRegion.put(1, "one");
//  Object val = myRegion.get(1);

       Random rand = new Random();
       int putNum = rand.nextInt(10000);
       
       try{
		   File file = new File("ApacheGeodeFullColor.png");
		   FileInputStream fstream = new FileInputStream(file);
		   ObjectInputStream ofile = new ObjectInputStream(fstream);
              
//        myRegion.put(putNum, "one");
		   
	       myRegion.put(putNum, ofile.readObject());
	       ofile.close();
	       fstream.close();
       }catch(IOException ioe){
    	   ioe.printStackTrace();
       } catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        int getNum = rand.nextInt(10000);
        
        Object val = myRegion.get(getNum);
//        if (!"one".equals(val)) {
//            throw new IllegalStateException("Expected value not returned, expected: one, found:" + val);
//        }

    //        return "ok";
        return "key is" + getNum + "value is" + (String)val;
    }

    @RequestMapping("/poolIdleTimeout")
    public Long getClientPoolIdleTimeout() {
        return cache.getDefaultPool().getIdleTimeout();
    }

    @ExceptionHandler()
    public void handleException(Exception ex, HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.INTERNAL_SERVER_ERROR.value(), getStackString(ex));
    }

    private String getStackString(Exception e) {
        StringBuilder s = new StringBuilder(e.getClass().getCanonicalName()).append(e.getMessage());
        for (StackTraceElement ste : e.getStackTrace()) {
            s.append("  at ").append(ste.toString()).append("\n");
        }
        return s.toString();
    }
}
